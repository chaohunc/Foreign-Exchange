package decisionTree;

import java.util.ArrayList;

public class Tuple {
	ArrayList<Double> columnValue;
	double labelValue;
	Tuple()
	{
		this.columnValue = new ArrayList<Double>();		
	}
}


