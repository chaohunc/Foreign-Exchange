package currecyDataPipeline;

public class Pair {
	long timestamp;
	String content;
	
	Pair (long timestamp, String content)
	{
		this.timestamp = timestamp;
		this.content = content;
	}
}
